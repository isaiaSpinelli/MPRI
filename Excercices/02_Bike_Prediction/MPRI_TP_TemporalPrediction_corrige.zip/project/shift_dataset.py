import pandas as pd

df = pd.DataFrame({'value(t)':range(100)})
df_shifted = df.shift(-1)
df['value(t+1)'] = df_shifted
df.dropna(inplace=True)  ## We finally remove the nan values (we lose some data here ... but it's ok)
print(df)