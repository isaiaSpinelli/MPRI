import json
import pandas
import numpy as np
import datetime
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split


def evaluate(station_id, plot_gini_coef=False, use_time_features=False, show_plot=False):

    def index_to_hour(x):
        return x.hour
    def index_to_weekday(x):
        return x.dayofweek

    ## Load raw data
    df = load_data(station_id)
    ## Process data (Note: data could also be normalized and/or one-hot encoded for better results)
    if use_time_features:
        # Extract hour and dayofweek information (from index) and add it to the df
        df['hour(t)'] = df.index.to_series().apply(index_to_hour)
        df['dayofweek(t)'] = df.index.to_series().apply(index_to_weekday)

    ## Split the data into train and test sets (important keep the temporal order)
    train_set, test_set = train_test_split(df, test_size=0.25, shuffle=False)

    ## Split the train_set into X_train (input data), y_train (output data)
    y_columns = ['bikes(t+15)', 'bikes(t+30)', 'bikes(t+60)']
    x_columns = df.columns.difference(y_columns)

    X_train_set = train_set.loc[:, x_columns]
    y_train_set = train_set.loc[:, y_columns]

    ## Split the test_set into X_test (input data), y_test (output data, aka ground truth)
    X_test_set = test_set.loc[:, x_columns]
    y_test_set = test_set.loc[:, y_columns]

    ## Initialisze the model and perform the training (fit)
    model = RandomForestRegressor(n_jobs=-1, n_estimators=10, random_state=0, verbose=1)
    model.fit(X_train_set, y_train_set)

    ## Perform the predictions
    predictions = model.predict(X_test_set)

    ## Convert the received predictions (list of lists) to a dataframe (specify columns names)
    pred_df = pandas.DataFrame(predictions, columns=y_test_set.columns)
    pred_df = pred_df.round(0).astype(int)

    ## Compare the predictions and the ground_truth(y_test_set)
    # print("Predictions:\n{}".format(pred_df))
    # print("Real values:\n{}".format(y_test_set))

    ## Get average error by horizon:
    error = pred_df.reset_index(drop=True).subtract(y_test_set.reset_index(drop=True), axis='columns')
    mean_absolute_error = error.abs().mean(axis=0)
    print("Mean absolute error: {}".format(mean_absolute_error))

    ## Plot Mean Absolute Error
    if show_plot:
        ax = mean_absolute_error.plot.bar(x='horizon', y='mae')
        for p in ax.patches:
            ax.annotate(np.round(p.get_height(), decimals=2), (p.get_x() + p.get_width() / 2., p.get_height()),
                        ha='center',
                        va='center', xytext=(0, 10), textcoords='offset points')
            plt.title('Mean absolute error (Station <{}>, time_features->{})'.format(station_id, use_time_features))
        plt.tight_layout()
        plt.show()

    ##Plot Gini coefficients and their importance
    if show_plot:
        importances = list(zip(model.feature_importances_, X_train_set.columns))
        importances.sort(reverse=True)
        pandas.DataFrame(importances, index=[x for (_, x) in importances]).plot(kind='bar')
        plt.tight_layout()  ## Tell students about that
        plt.title('Gini coefficients (Station <{}>), time_features->{})'.format(station_id, use_time_features))
        plt.show()

    return mean_absolute_error


""" 
    Load the data from a file and return it as a panda dataframe 
    Columns:  'bikes(t-20)', 'bikes(t-15)', 'bikes(t-10)', 'bikes(t-5)',  ## (int) number of bikes present at the station t minutes ago
       'holiday_type(t)',                                                 ## (int) the type of holiday (none, school, public)  
       'client_arrivals(t)', 'client_departures(t)',                      ## (int) the number of departures/arrivals at this station during the last 5 minutes
       'cur_temperature(t)', 'cur_humidity(t)', 'cur_cloudiness(t)',      ## (float) the current weather information  
       'cur_wind(t)', 
       'f3h_temperature(t)', 'f3h_humidity(t)', 'f3h_cloudiness(t)',      ## (float) the 3h forecasted weather information
       'f3h_wind(t)', 
       'client_departures_s43(t-20)', 'client_departures_s43(t-15)',      ## (int) the number of departures at the neighbouring stations (s_##) t minutes ago
       'client_departures_s43(t-10)',
       'client_departures_s43(t-5)', 'client_departures_s43(t)',
       'client_departures_s12(t-20)', 'client_departures_s12(t-15)',
       'client_departures_s12(t-10)', 'client_departures_s12(t-5)',
       'client_departures_s12(t)', 'client_departures_s22(t-20)',
       'client_departures_s22(t-15)', 'client_departures_s22(t-10)',
       'client_departures_s22(t-5)', 'client_departures_s22(t)',
       'client_departures_s15(t-20)', 'client_departures_s15(t-15)',
       'client_departures_s15(t-10)', 'client_departures_s15(t-5)',
       'client_departures_s15(t)', 'client_departures_s36(t-20)',
       'client_departures_s36(t-15)', 'client_departures_s36(t-10)',
       'client_departures_s36(t-5)', 'client_departures_s36(t)', 
       'bikes(t)',                                                      ## The current number of bikes at the station
       'bikes(t+15)', 'bikes(t+30)', 'bikes(t+60)'                      ## The future number of bikes at the station (those are the values to predict)
    
"""
def load_data(station_id):
    with open("data/station_data_{}.json".format(station_id)) as ifile:
        json_data = json.load(ifile)
        dataframe = pandas.read_json(json_data)
        #print("Columns of the dataframe: \n{}".format(dataframe.columns))
    return dataframe


if __name__ == "__main__":
    station_ids = [0, 1, 2]
    use_time_features = [False, True]

    results = pandas.DataFrame(index=station_ids, columns=use_time_features)

    for station_id in station_ids:
        for use_time_features in [False, True]:
            mae = evaluate(station_id=station_id, use_time_features=use_time_features, show_plot=False)
            results.at[station_id, use_time_features] = mae

    print("Final results:")
    print(results)

    with open("data/results.json", 'w') as ofile:
        results.to_json(ofile)
